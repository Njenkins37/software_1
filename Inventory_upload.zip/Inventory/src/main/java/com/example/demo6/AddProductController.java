package com.example.demo6;

import Inventory.Inventory;
import Inventory.Part;
import Inventory.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import static Inventory.Inventory.addProduct;

/***
 * I encountered several NullPointerExceptions with the add and modify product controllers.
 * Numerous times I would try to call a product in order to add parts only to receive the NullPointerException. I was able to remove and add associated parts by not utilizing the methods.
 * I also had trouble passing the search text field into either a string or the int and then searching the observable list and returning the product. I was usually able to do one or the other, but I wasn't able to search as both.
 * I eventually just made two if statements: one for string and one for int which appears to have sufficed.
 * A future enhancement for this class could be location most sold, or including geographic regions of distribution of sales to record these numbers and improve profits.
 */
public class AddProductController implements Initializable{
    @FXML
    Stage stage;
    @FXML
    Scene scene;
    @FXML
    TableView<Part> partTable;
    @FXML
    private TextField productId;
    @FXML
    private TextField productName;
    @FXML
    private TextField productStock;
    @FXML
    private TextField productPrice;
    @FXML
    private TextField productMax;
    @FXML
    private TextField productMin;
    @FXML
    private TableColumn<Part, Integer> columnPartID;
    @FXML
    private TableColumn<Part, String> columnPartName;
    @FXML
    private TableColumn<Part, Integer> columnPartInvLevel;
    @FXML
    private TableColumn<Part, Double> columnPartPrice;
    @FXML
    private TableColumn<Part, Integer> columnPartIDBottom;
    @FXML
    private TableColumn<Part, String> columnPartNameBottom;
    @FXML
    private TableColumn<Part, Integer> columnPartInvLevelBottom;
    @FXML
    private TableColumn<Part, Double> columnPartPriceBottom;
    @FXML
    TableView<Part> bottomTable;
    @FXML
    Button addAssociatedPartButton;
    @FXML
    Button removeAssociatedPartButton;
    @FXML
    TextField searchField;
    @FXML
    private ObservableList<Part> associatedPart = FXCollections.observableArrayList();
    ObservableList<Part> testList = FXCollections.observableArrayList();

    static int count = 3;
    Product product = new Product(0, "", 0, 0, 0, 0);


    public void initialize(URL url, ResourceBundle rb) {
        columnPartID.setCellValueFactory(new PropertyValueFactory<Part, Integer>("id"));
        columnPartName.setCellValueFactory(new PropertyValueFactory<Part, String>("name"));
        columnPartInvLevel.setCellValueFactory(new PropertyValueFactory<Part, Integer>("stock"));
        columnPartPrice.setCellValueFactory(new PropertyValueFactory<Part, Double>("price"));
        partTable.setItems(Inventory.getAllParts());
        partTable.getSortOrder().add(columnPartID);
        
    }

    @FXML
    public void onCloseProductButtonClick(ActionEvent event) throws IOException {
        this.product.getAllAssociatedParts().clear();
        product.getAllAssociatedParts().addAll(testList);
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Scene1.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(fxmlLoader.load(), 850, 550);
        stage.setTitle("Inventory Management");
        stage.setScene(scene);
        stage.show();
    }

    /***
     * RUNTIME ERROR Number format exception
     * @param event
     * @throws IOException
     */
    @FXML
    public void onSaveProductButton(ActionEvent event) throws IOException {
        if(inputValidation()) {
            String name = productName.getText();
            int stock = Integer.parseInt(productStock.getText());
            double price = Double.parseDouble(productPrice.getText());
            int max = Integer.parseInt(productMax.getText());
            int min = Integer.parseInt(productMin.getText());
            Product product2 = new Product(count, name, price, stock, min, max);
            this.product = product2;
            addProduct(product2);
            count++;

        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("Input must be valid. Max must be greater than Min, and Stock must be between Max and Min");
            alert.showAndWait();
        }

        if(inputValidation()) {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Scene1.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(fxmlLoader.load(), 850, 550);
            stage.setTitle("Inventory Management");
            stage.setScene(scene);
            stage.show();
        }
    }
    @FXML
    public void setAddAssociatedPartButton(ActionEvent event) throws IOException{

        columnPartIDBottom.setCellValueFactory(new PropertyValueFactory<Part, Integer>("id"));
        columnPartNameBottom.setCellValueFactory(new PropertyValueFactory<Part, String>("name"));
        columnPartInvLevelBottom.setCellValueFactory(new PropertyValueFactory<Part, Integer>("stock"));
        columnPartPriceBottom.setCellValueFactory(new PropertyValueFactory<Part, Double>("price"));
        bottomTable.setItems(product.getAllAssociatedParts());
        //this.product = product;
        Part selectedPart = partTable.getSelectionModel().getSelectedItem();
        this.product.addAssociatedPart(selectedPart);
        testList.addAll(product.getAllAssociatedParts());
        //product.getAllAssociatedParts().addAll(this.product.getAllAssociatedParts());
        //this.product.getAllAssociatedParts().addAll(this.product.getAllAssociatedParts());
        //System.out.println(product);
        //associatedPart.add(selectedPart);
        //bottomTable.setItems(associatedPart);

    }

    @FXML
    public void setRemoveAssociatedPartButton(ActionEvent event) throws IOException{

        Part part = bottomTable.getSelectionModel().getSelectedItem();

        if (part == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No Product Selected");
            alert.setContentText("You did not select a part to delete.");
            alert.showAndWait();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete Part");
            alert.setContentText("You are about to delete a part. Click Ok to continue");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                part = bottomTable.getSelectionModel().getSelectedItem();
                this.product.deleteAssociatedPart(part);
                //bottomTable.setItems(associatedPart);
            }
        }

    }

    public void onSearchText(ActionEvent event) throws IOException {
        int search1 = 0;
        String search2 = null;

        try {
            search1 = Integer.parseInt(searchField.getText());
        } catch (NumberFormatException e) {
            search2 = searchField.getText();
        }
        if (search1 != 0) {
            ObservableList<Part> filterParts = FXCollections.observableArrayList();
            Part part = Inventory.lookupPart(search1);
            if (part == null) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("No Matching Parts");
                alert.setContentText("The part you searched for was not found.");
                alert.showAndWait();
            } else {
                filterParts.add(part);
                partTable.setItems(filterParts);
            }
        }
        if (search2 != null)
        {
            ObservableList<Part> filterParts = Inventory.lookupPart(search2);
            if (!filterParts.isEmpty()) {
                partTable.setItems(filterParts);
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("No Matching Parts");
                alert.setContentText("The part you searched for was not found.");
                alert.showAndWait();
            }
        }
    }

    public boolean inputValidation() {
        try {
            int maximum = Integer.parseInt(productMax.getText());
            int minimum = Integer.parseInt(productMin.getText());
            int stock = Integer.parseInt(productStock.getText());
            double price = Double.parseDouble(productPrice.getText());
            if (maximum >= stock && stock >= minimum) {
                return true;
            }

        } catch (NumberFormatException e) {
            System.out.println("Error");
        }
        return false;
    }
}

