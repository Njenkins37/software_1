package com.example.demo6;

import Inventory.Product;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import Inventory.InHouse;

import static Inventory.Inventory.addPart;
import static Inventory.Inventory.addProduct;


/***Location of JavaDocs
 * C:\Users\Nick\IdeaProjects\demo6\src\main\java\com\example\demo6
 */
public class Main extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Scene1.fxml"));
        //Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 850, 450);
        stage.setTitle("Inventory Management");
        stage.setScene(scene);
        stage.show();
    }


    public static void main(String[] args) {
        InHouse part1 = new InHouse(1, "Brakes", 15.00, 10, 1, 20, 1);
        InHouse part2 = new InHouse(2, "Wheel", 11.00, 16, 1, 20, 2);
        InHouse part3 = new InHouse(3, "Seat", 15.00, 10, 1, 20, 3);

        addPart(part1);
        addPart(part2);
        addPart(part3);

        Product product1 = new Product(1, "Giant Bike", 299.99, 15, 1, 20);
        Product product2 = new Product(2, "Unicycle", 99.99, 20, 1, 20);

        addProduct(product1);
        addProduct(product2);

        launch();
    }
}