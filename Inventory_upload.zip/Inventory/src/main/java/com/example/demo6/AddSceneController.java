package com.example.demo6;

import Inventory.InHouse;
import Inventory.OutSource;
import Inventory.Part;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static Inventory.Inventory.addPart;

/***
 * I received numerous NumberFormatException errors for this class. Before I was attempting to run the Parts Class as a concrete class and attempting to instantiate it within the save parts action panel.
 * I wasn't able to accommodate for the in house versus out source selections which would result in my exceptions. After making the parts class abstract and making the inventory class, I was able to correctly
 * create an in house object or an outsource object. Potential improvements could also include visual representation of the parts or including weight of part that way stock * weight could give the consumer
 * an idea of how much weight they are storing total and shipping costs to be concerned about.
 */
public class AddSceneController {
    @FXML
    private Stage stage;
    @FXML
    private Scene scene;
    private Parent root;
    @FXML
    private TextField partIDField;
    @FXML
    private TextField partNameField;
    @FXML
    private TextField partInvField;
    @FXML
    private TextField partPriceField;
    @FXML
    private TextField partMaxField;
    @FXML
    private TextField partMinField;
    @FXML
    private TextField bottomTextField;
    @FXML
    private Label bottomLabel;
    @FXML
    RadioButton inHouseButton;
    @FXML
    RadioButton outSourceButton;
    //private TextField partMachineField;
    static int count = 4;


    @FXML
    public void onCloseButtonClick(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Scene1.fxml"));
        //Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load(), 850, 450);
        stage.setTitle("Inventory Management");
        stage.setScene(scene);
        stage.show();

    }

    /***
     * RUNTIMEERROR NumberFormatException due to bottom text field.
     * @param event
     * @throws IOException
     */
    public void onSavePartButtonClick(ActionEvent event) throws IOException {
        //int id = Integer.parseInt(partIDField.getText());
        if(inputValidation()) {
            String name = partNameField.getText();
            int stock = Integer.parseInt(partInvField.getText());
            double price = Double.parseDouble(partPriceField.getText());
            int max = Integer.parseInt(partMaxField.getText());
            int min = Integer.parseInt(partMinField.getText());

            if (inHouseButton.isSelected()) {
                int bottomField = Integer.parseInt(bottomTextField.getText());
                InHouse inHouse = new InHouse(count, name, price, stock, min, max, bottomField);
                Part part = inHouse;
                addPart(part);
            } else {
                String companyName = bottomTextField.getText();
                OutSource outSource = new OutSource(count, name, price, stock, min, max, companyName);
                Part part = outSource;
                addPart(part);
            }

        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("Input must be valid. Max must be greater than Min, and Stock must be between Max and Min");
            alert.showAndWait();
        }

        if(inputValidation()) {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Scene1.fxml"));
            //Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(fxmlLoader.load(), 850, 450);
            stage.setTitle("Inventory Management");
            stage.setScene(scene);
            stage.show();
        }
    }

    @FXML
    public void onOutSourceButtonClick(ActionEvent event) throws IOException {
        bottomLabel.setText("Company Name");
    }

    public void onInHouseButtonClick(ActionEvent event) throws IOException {
        bottomLabel.setText("Machine ID");
    }

    @FXML
    public void onCLoseButtonModifyOutSource(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Scene1.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(fxmlLoader.load(), 850, 550);
        stage.setTitle("Inventory Management");
        stage.setScene(scene);
        stage.show();
    }

    public boolean inputValidation() {
        try {
            int maximum = Integer.parseInt(partMaxField.getText());
            int minimum = Integer.parseInt(partMinField.getText());
            int stock = Integer.parseInt(partInvField.getText());
            double price = Double.parseDouble(partPriceField.getText());
            if ((maximum >= stock && stock >= minimum)) {
                return true;
            }

        } catch (NumberFormatException e) {
            System.out.println("Error");
        }
        return false;
    }

}


