package com.example.demo6;

import Inventory.Part;
import Inventory.Product;
import Inventory.InHouse;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import Inventory.Inventory;
import Inventory.Product;

/***
 * I kept receiving NullPointerExceptions when attempting to create my tables and columns. I had a lot of trouble keeping observable lists and table view methods separate, and I probably still do.
 * It was difficult for me to remember to set items for a TableView and add an object to the observable list or which one I could get selection model. I have a better understanding of these terms now,
 * but it took time to get better with these terms. Depending on the customer, adding location of parts or product could be a future enhancement for again idea of cost of shipping and possible global distribution.
 *
 */
public class SceneController implements Initializable {
    @FXML
    private Stage stage;
    @FXML
    private Scene scene;
    private Parent root;
    @FXML
    private TextField searchFieldPart;
    @FXML
    private TextField searchFieldProduct;

    @FXML
    private TableView<Part> partTable;
    @FXML
    private TableView<Product> productTable;
    @FXML
    private TableColumn<Part, Integer> columnPartID;
    @FXML
    private TableColumn<Part, String> columnPartName;
    @FXML
    private TableColumn<Part, Integer> columnPartInvLevel;
    @FXML
    private TableColumn<Part, Double> columnPartPrice;
    @FXML
    private TableColumn<Product, Integer> columnProductID;
    @FXML
    private TableColumn<Product, String> columnProductName;
    @FXML
    private TableColumn<Product, Integer> columnProductInvLevel;
    @FXML
    private TableColumn<Product, Double> columnProductPrice;

    /***
     * RUNTIME ERROR: NullPointerExceptions caused when learning how to set tables.
     * @param url
     * @param rb
     */
    public void initialize(URL url, ResourceBundle rb) {
        columnPartID.setCellValueFactory(new PropertyValueFactory<Part, Integer>("id"));
        columnPartName.setCellValueFactory(new PropertyValueFactory<Part, String>("name"));
        columnPartInvLevel.setCellValueFactory(new PropertyValueFactory<Part, Integer>("stock"));
        columnPartPrice.setCellValueFactory(new PropertyValueFactory<Part, Double>("price"));
        partTable.setItems(Inventory.getAllParts());
        partTable.getSortOrder().add(columnPartID);

        columnProductID.setCellValueFactory(new PropertyValueFactory<Product, Integer>("id"));
        columnProductName.setCellValueFactory(new PropertyValueFactory<Product, String>("name"));
        columnProductInvLevel.setCellValueFactory(new PropertyValueFactory<Product, Integer>("stock"));
        columnProductPrice.setCellValueFactory(new PropertyValueFactory<Product, Double>("price"));
        productTable.setItems(Inventory.getAllProducts());
        productTable.getSortOrder().add(columnProductID);

    }


    public void onAddButtonClick(ActionEvent event) throws IOException {
        //Parent root = FXMLLoader.load(getClass().getResource("AddScene.fxml"));
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AddScene.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(fxmlLoader.load(), 850, 550);
        stage.setTitle("Add Part");
        stage.setScene(scene);
        stage.show();

    }

    public void onCloseButtonClick(ActionEvent event) {
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();

    }

    public void onModifyButtonClick(ActionEvent event) throws IOException {
            Part part  = partTable.getSelectionModel().getSelectedItem();
            if (part == null) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("No Part Selected");
                alert.setContentText("Please select a part to modify to continue");
                alert.showAndWait();
            }

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("ModifyScene.fxml"));
        loader.load();

        ModifyPartController partController = loader.getController();
        partController.sendPart(partTable.getSelectionModel().getSelectedItem());

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        stage.setTitle("Modify Part");
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();

        //FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("ModifyScene.fxml"));

    }
    public void onAddProductButtonClick(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AddProductScene.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(fxmlLoader.load(), 850, 550);
        stage.setTitle("Add Part");
        stage.setScene(scene);
        stage.show();
    }

    /***
     * RUNTIME ERROR: NullPointerException. Needed to work in the warning box for not having an object selected.
     * @param event
     * @throws IOException
     */
    public void onModifyProductScene(ActionEvent event) throws IOException {
        Product product = productTable.getSelectionModel().getSelectedItem();
        if(product == null)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No product selected.");
            alert.setContentText("You did not select a product to modify. Please select a product.");
            alert.showAndWait();
        }

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("ModifyProductScene.fxml"));
        loader.load();

        ModifyProductController partController = loader.getController();
        partController.sendProduct(productTable.getSelectionModel().getSelectedItem());

        Parent scene = loader.getRoot();
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        stage.setTitle("Modify Product");
        stage.setScene(new Scene(scene));
        stage.show();
    }

    public void onSearchText(ActionEvent event) throws IOException {
        int search1 = 0;
        String search2 = null;

        try {
            search1 = Integer.parseInt(searchFieldPart.getText());
        } catch (NumberFormatException e) {
            //System.out.println("Test");
            search2 = searchFieldPart.getText();
        }
            if (search1 != 0) {
                //ObservableList<Part> filterParts = Inventory.lookupPart(search1);
                ObservableList<Part> filterParts = FXCollections.observableArrayList();
                Part part = Inventory.lookupPart(search1);
                if (part == null) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("No Matching Parts");
                    alert.setContentText("The part you searched for was not found.");
                    alert.showAndWait();
                } else {
                    filterParts.add(part);
                    partTable.setItems(filterParts);
                }
            }
         if (search2 != null)
         {
             ObservableList<Part> filterParts = Inventory.lookupPart(search2);
             if (!filterParts.isEmpty()) {
                 partTable.setItems(filterParts);
             } else {
                 Alert alert = new Alert(Alert.AlertType.ERROR);
                 alert.setTitle("No Matching Parts");
                 alert.setContentText("The part you searched for was not found.");
                 alert.showAndWait();
             }
         }
    }

    /***
     * RUNTIME ERROR: typing in the text field would cause a run time error.
     * @param event
     * @throws IOException
     */
    public void setSearchFieldProduct(ActionEvent event) throws IOException {
        int search1 = 0;
        String search2 = null;

        try {
            search1 = Integer.parseInt(searchFieldProduct.getText());
        } catch (NumberFormatException e) {
            //System.out.println("Test");
            search2 = searchFieldProduct.getText();
        }
        if (search1 != 0) {
            //ObservableList<Part> filterParts = Inventory.lookupPart(search1);
            ObservableList<Product> filterProducts = FXCollections.observableArrayList();
            Product product = Inventory.lookupProduct(search1);
            if (product == null) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("No Matching Parts");
                alert.setContentText("The part you searched for was not found.");
                alert.showAndWait();
            } else {
                filterProducts.add(product);
                productTable.setItems(filterProducts);
            }
        }
        if (search2 != null)
        {
            ObservableList<Product> filterProducts = Inventory.lookupProduct(search2);
            if (!filterProducts.isEmpty()) {
                productTable.setItems(filterProducts);
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("No Matching Parts");
                alert.setContentText("The part you searched for was not found.");
                alert.showAndWait();
            }
        }
    }

    /***
     * RUNTIME ERROR: NullPointerException. No method for handling null values. Method created to solve problem.
     * @param event
     * @throws IOException
     */
    public void onDeletePartButtonClick(ActionEvent event) throws IOException{
        Part part = partTable.getSelectionModel().getSelectedItem();

        if (part == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No Product Selected");
            alert.setContentText("You did not select a part to delete.");
            alert.showAndWait();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete Part");
            alert.setContentText("You are about to delete a part. Click Ok to continue");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                part = partTable.getSelectionModel().getSelectedItem();
                Inventory.deletePart(part);
            }
        }
    }

    /***
     * RUNTIME ERROR: Null pointer exception
     * @param event
     * @throws IOException
     */
    public void onDeleteProductButtonClick(ActionEvent event) throws IOException {
        Product product = productTable.getSelectionModel().getSelectedItem();
        ObservableList<Part> associatedParts  = product.getAllAssociatedParts();


        if (product == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No Product Selected");
            alert.setContentText("You did not select a part to delete.");
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete Part");
            alert.setContentText("You are about to delete a part. Click Ok to continue");
            Optional<ButtonType> result = alert.showAndWait();

            associatedParts = product.getAllAssociatedParts();
            if(!associatedParts.isEmpty())
            {
                Alert alert2 = new Alert(Alert.AlertType.ERROR);
                alert2.setTitle("Unable to delete product");
                alert2.setContentText("Product has associated parts and cannot be deleted");
                alert2.showAndWait();

            }

            if (result.isPresent() && result.get() == ButtonType.OK && associatedParts.isEmpty()) {
                    Product product2 = productTable.getSelectionModel().getSelectedItem();
                    Inventory.deleteProduct(product2);
                }

            }

        }

}
