package com.example.demo6;

import Inventory.InHouse;
import Inventory.Part;
import Inventory.OutSource;
import Inventory.Product;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static Inventory.Inventory.*;

/***
 * For the modify part/product panes, I struggled with the ability to pass information from scene to scene. I did a lot of searching for the FXML loader and watched the webinar series multiple times to be able to pass this information.
 * I was able to keep the number format exceptions relatively low. Future enhancements of this class could include adding visual representation of parts depending on the consumer's needs.
 */
public class ModifyPartController{
    @FXML
    private TextField partIdField;
    @FXML
    private TextField partNameField;
    @FXML
    private TextField partInvField;
    @FXML
    private TextField partPriceField;
    @FXML
    private TextField partMaxField;
    @FXML
    private TextField partMinField;
    @FXML
    private TextField bottomTextField;
    @FXML
    private Label bottomLabel;
    @FXML
    RadioButton inHouseButton;
    @FXML
    RadioButton outSourceButton;
    @FXML Stage stage;
    @FXML
    Scene scene;

    public void onModifyOutsourceButtonClick (ActionEvent event) throws IOException {
        bottomLabel.setText("Company Name");
    }

    public void onModifyInHouseButtonClick(ActionEvent event) throws IOException {
        bottomLabel.setText("Machine ID");
    }

    public void onCLoseButtonModifyOutSource(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Scene1.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(fxmlLoader.load(), 850, 550);
        stage.setTitle("Inventory Management System");
        stage.setScene(scene);
        stage.show();
    }

    /***
     * RUNTIME ERROR NumberFormatException with the bottom text field.
     * @param part
     */
    public void sendPart(Part part){
        partIdField.setText(String.valueOf(part.getId()));
        partNameField.setText(part.getName());
        partInvField.setText(String.valueOf(part.getStock()));
        partPriceField.setText(String.valueOf(part.getPrice()));
        partMinField.setText(String.valueOf(part.getMax()));
        partMaxField.setText(String.valueOf(part.getMin()));
        if(part instanceof InHouse)
        {
            inHouseButton.setSelected(true);
            bottomTextField.setText(String.valueOf(((InHouse)part).getMachineId()));
        }
        else {
            bottomLabel.setText("Company Name");
            outSourceButton.setSelected(true);
            bottomTextField.setText(((OutSource)part).getCompanyName());
        }

    }



    public void onSaveModificationButton(ActionEvent event) throws IOException{
        if(inputValidation()) {
            int id = Integer.parseInt(partIdField.getText());
            String name = partNameField.getText();
            int stock = Integer.parseInt(partInvField.getText());
            double price = Double.parseDouble(partPriceField.getText());
            int min = Integer.parseInt(partMinField.getText());
            int max = Integer.parseInt(partMaxField.getText());


            if (inHouseButton.isSelected()) {

                int bottomField = Integer.parseInt(bottomTextField.getText());
                InHouse inHouse = new InHouse(id, name, price, stock, min, max, bottomField);
                Part part = inHouse;
                int test = id - 1;
                updatePart(test, part);
            } else {
                String companyName = bottomTextField.getText();
                OutSource outSource = new OutSource(id, name, price, stock, min, max, companyName);
                Part part = outSource;
                int test = id - 1;
                updatePart(test, part);
            }
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("Input must be valid. Max must be greater than Min, and Stock must be between Max and Min");
            alert.showAndWait();
        }


        if(inputValidation()) {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Scene1.fxml"));
            //Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(fxmlLoader.load(), 850, 450);
            stage.setTitle("Inventory Management");
            stage.setScene(scene);
            stage.show();
        }

    }

    public boolean inputValidation() {
        try {
            int maximum = Integer.parseInt(partMaxField.getText());
            int minimum = Integer.parseInt(partMinField.getText());
            int stock = Integer.parseInt(partInvField.getText());
            double price = Double.parseDouble(partPriceField.getText());
            if ((maximum >= stock && stock >= minimum)) {
                return true;
            }

        } catch (NumberFormatException e) {
            System.out.println("Error");
        }
        return false;
    }

}


