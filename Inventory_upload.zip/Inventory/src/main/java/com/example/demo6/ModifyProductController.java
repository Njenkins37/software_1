package com.example.demo6;

import Inventory.Part;
import Inventory.Inventory;
import Inventory.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/***
 * For the modify part/product panes, I struggled with the ability to pass information from scene to scene. I did a lot of searching for the FXML loader and watched the webinar series multiple times to be able to pass this information.
 * I was able to keep the number format exceptions relatively low. Future enhancements of this class could include adding visual representation of parts depending on the consumer's needs.
 */


public class ModifyProductController implements Initializable {
    @FXML
    Stage stage;
    @FXML
    Scene scene;
    @FXML
    TableView<Part> partTable;
    @FXML
    private TableColumn<Part, String> columnPartID;
    @FXML
    private TableColumn<Part, String> columnPartName;
    @FXML
    private TableColumn<Part, String> columnPartInvLevel;
    @FXML
    private TableColumn<Part, String> columnPartPrice;
    @FXML
    private TableColumn<Part, String> columnPartIDBottom;
    @FXML
    private TableColumn<Part, String> columnPartNameBottom;
    @FXML
    private TableColumn<Part, String> columnPartInvLevelBottom;
    @FXML
    private TableColumn<Part, String> columnPartPriceBottom;
    @FXML
    TableView<Part> bottomTable;
    @FXML
    private TextField productId;
    @FXML
    private TextField productName;
    @FXML
    private TextField productStock;
    @FXML
    private TextField productPrice;
    @FXML
    private TextField productMax;
    @FXML
    private TextField productMin;
    @FXML
    TextField searchField;
    @FXML
    Button saveButton;
    Product product;
    ObservableList<Part> associatedPartList = FXCollections.observableArrayList();
    ObservableList<Part> testList = FXCollections.observableArrayList();



    public void initialize(URL url, ResourceBundle rb) {
        columnPartID.setCellValueFactory(new PropertyValueFactory<Part, String>("id"));
        columnPartName.setCellValueFactory(new PropertyValueFactory<Part, String>("name"));
        columnPartInvLevel.setCellValueFactory(new PropertyValueFactory<Part, String>("inventory"));
        columnPartPrice.setCellValueFactory(new PropertyValueFactory<Part, String>("price"));
        partTable.setItems(Inventory.getAllParts());
    }

    public void sendProduct(Product product){
        bottomTable.setItems(product.getAllAssociatedParts());
        columnPartIDBottom.setCellValueFactory(new PropertyValueFactory<Part, String>("id"));
        columnPartNameBottom.setCellValueFactory(new PropertyValueFactory<Part, String>("name"));
        columnPartInvLevelBottom.setCellValueFactory(new PropertyValueFactory<Part, String>("inventory"));
        columnPartPriceBottom.setCellValueFactory(new PropertyValueFactory<Part, String>("price"));
        productId.setText(String.valueOf(product.getId()));
        productName.setText(product.getName());
        productStock.setText(String.valueOf(product.getStock()));
        productPrice.setText(String.valueOf(product.getPrice()));
        productMin.setText(String.valueOf(product.getMin()));
        productMax.setText(String.valueOf(product.getMax()));
        this.product = product;
        testList.addAll(product.getAllAssociatedParts());

    }

    public void onCloseProductButtonClick(ActionEvent event) throws IOException {
        this.product.getAllAssociatedParts().clear();
        product.getAllAssociatedParts().addAll(testList);
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Scene1.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(fxmlLoader.load(), 850, 550);
        stage.setTitle("Inventory Management");
        stage.setScene(scene);
        stage.show();
    }

    /***
     * RUNTIME ERROR: numerous NumberFormat Exceptions. Had to create variables to get data.
     * @param event
     * @throws IOException
     */
    public void setOnSaveButton(ActionEvent event) throws IOException{
        if(inputValidation()) {
            int id = Integer.parseInt(productId.getText());
            String name = productName.getText();
            int stock = Integer.parseInt(productStock.getText());
            double price = Double.parseDouble(productPrice.getText());
            int max = Integer.parseInt(productMax.getText());
            int min = Integer.parseInt(productMin.getText());
            Product product2 = new Product(id, name, price, stock, min, max);
            product2.getAllAssociatedParts().addAll(this.product.getAllAssociatedParts());
            //Inventory.updateProduct(id - 1, product);
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("Input must be valid. Max must be greater than Min, and Stock must be between Max and Min");
            alert.showAndWait();

        }
           if(inputValidation()) {
               FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Scene1.fxml"));
               stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
               scene = new Scene(fxmlLoader.load(), 850, 550);
               stage.setTitle("Inventory Management");
               stage.setScene(scene);
               stage.show();
           }


    }

    public void setOnAddAssociatedPartButton(ActionEvent event) throws IOException{
        //int id = Integer.parseInt(productId.getText());
        //String name = productName.getText();
        //int stock = Integer.parseInt(productStock.getText());
        //double price = Double.parseDouble(productPrice.getText());
        //int max = Integer.parseInt(productMax.getText());
        //int min = Integer.parseInt(productMin.getText());
        //Product product = new Product(id, name, price, stock, min, max);
        Part part = partTable.getSelectionModel().getSelectedItem();
        System.out.println(part);
        this.product.addAssociatedPart(part);
        //associatedPartList.add(part);
        //bottomTable.setItems(product.getAllAssociatedParts());


    }

    /***
     * FUTURE ENHANCEMENT: Making a warning, confirmation, alert class to save redundancy.
     * @param event
     * @throws IOException
     */
    public void removeAssociatedPartButton(ActionEvent event) throws IOException{

        Part part = bottomTable.getSelectionModel().getSelectedItem();

        if (part == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No Product Selected");
            alert.setContentText("You did not select a part to delete.");
            alert.showAndWait();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete Part");
            alert.setContentText("You are about to delete a part. Click Ok to continue");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                part = bottomTable.getSelectionModel().getSelectedItem();
                this.product.deleteAssociatedPart(part);
                //associatedPartList.remove(part);
                //bottomTable.setItems(associatedPartList);
            }
        }
    }

    /***
     * Didn't cause run time errors, but was difficult to get it to work.
     * @param event
     * @throws IOException
     */
    public void onSearchText(ActionEvent event) throws IOException {
        int search1 = 0;
        String search2 = null;

        try {
            search1 = Integer.parseInt(searchField.getText());
        } catch (NumberFormatException e) {
            search2 = searchField.getText();
        }
        if (search1 != 0) {
            ObservableList<Part> filterParts = FXCollections.observableArrayList();
            Part part = Inventory.lookupPart(search1);
            if (part == null) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("No Matching Parts");
                alert.setContentText("The part you searched for was not found.");
                alert.showAndWait();
            } else {
                filterParts.add(part);
                partTable.setItems(filterParts);
            }
        }
        if (search2 != null)
        {
            ObservableList<Part> filterParts = Inventory.lookupPart(search2);
            if (!filterParts.isEmpty()) {
                partTable.setItems(filterParts);
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("No Matching Parts");
                alert.setContentText("The part you searched for was not found.");
                alert.showAndWait();
            }
        }
    }

    public ObservableList<Part> sendAssociatedParts(Product product){
       return product.getAllAssociatedParts();
    }

    public boolean inputValidation() {
        try {
            int maximum = Integer.parseInt(productMax.getText());
            int minimum = Integer.parseInt(productMin.getText());
            int stock = Integer.parseInt(productStock.getText());
            double price = Double.parseDouble(productPrice.getText());
            if (maximum >= stock && stock >= minimum) {
                return true;
            }

        } catch (NumberFormatException e) {
            System.out.println("Error");
        }
        return false;
    }
}

