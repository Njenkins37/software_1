package Inventory;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/***
 * Product class. I had substantial problems attempting to get the methods in the product class to be usable for getting part Items.
 * THe UML stated that it had to be an instance method, and I wasn't sure how to create a Product while using Parts to return the Observable List.
 *
 */

public class Product {
    private int id;
    private String name;
    private int stock;
    private double price;
    private int max;
    private int min;
    private ObservableList<Part> associatedParts = FXCollections.observableArrayList();



    public Product(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public void addAssociatedPart(Part part){
        associatedParts.add(part);

    }
    public boolean deleteAssociatedPart(Part selectedAssociatedPart){
        associatedParts.remove(selectedAssociatedPart);
    return true;
    }

    public ObservableList<Part> getAllAssociatedParts(){
        return associatedParts;
    }
}

