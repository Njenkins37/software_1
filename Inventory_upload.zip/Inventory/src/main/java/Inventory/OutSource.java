package Inventory;

public class OutSource extends Part{
    private String companyName;
    public OutSource(int id, String name, double price, int stock, int min, int max, String companyName){
        super(id, name, price, stock, max, min);
        this.companyName = companyName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}
