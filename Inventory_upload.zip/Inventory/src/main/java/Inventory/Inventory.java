package Inventory;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.List;
import java.util.Objects;

/***
 * Inventory Class. I was attempting to add parts to the observable list without having this class, and it was appearing impossible. After being advised to reread the UML, I separated methods and was able to add the necessary parts.
 *
 */

public class Inventory {
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();

    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();
    public static void addPart(Part part){
        allParts.add(part);
    }
    public static void addProduct(Product product){
        allProducts.add(product);
    }
    public static ObservableList<Part> getAllParts(){
        return allParts;
    }
    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }

    public static Part lookupPart(int partId){
        Part searchPart = null;
        for(Part part : Inventory.getAllParts())
        {
            if (part.getId() == partId)
            {
               searchPart = part;
               return searchPart;
            }
        }
        return searchPart;

    }
    public static ObservableList<Part> lookupPart(String partName){
        ObservableList<Part> searchedParts = FXCollections.observableArrayList();
        for (Part part : Inventory.getAllParts())
        {
            if(part.getName().toLowerCase().contains(partName.toLowerCase()))
            {
                searchedParts.add(part);
            }
        }
        return searchedParts;
    }

    public static Product lookupProduct(int productId){
        Product searchProduct = null;
        for(Product product : Inventory.getAllProducts())
        {
            if (product.getId() == productId)
            {
                searchProduct = product;
            }
        }
        return searchProduct;
    }

    public static ObservableList<Product> lookupProduct(String productName){
        ObservableList<Product> searchedParts = FXCollections.observableArrayList();
        for(Product product : Inventory.getAllProducts())
        {
            if (product.getName().toLowerCase().contains(productName.toLowerCase()))
            {
                searchedParts.add(product);
            }
        }
        return searchedParts;
    }

    public static boolean deletePart(Part selectedPart){
        for(Part part : Inventory.getAllParts())
        {
            if (part.getId() == selectedPart.getId() || Objects.equals(part.getName(), selectedPart.getName()))
            {
                allParts.remove(selectedPart);

                return true;
            }
        }
        return false;

    }
    public static boolean deleteProduct(Product selectedProduct) {
        allProducts.remove(selectedProduct);
        return true;
    }

    public static void updatePart( int index, Part selectedPart){
        allParts.set(index, selectedPart);

    }
    public static void updateProduct(int index, Product newProduct){
        allProducts.set(index, newProduct);

    }


}
